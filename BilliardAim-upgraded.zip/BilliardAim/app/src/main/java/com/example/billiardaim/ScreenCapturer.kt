package com.example.billiardaim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock

/**
 * Thu khung hình màn hình bằng MediaProjection trên luồng nền.
 * Để máy không bị đơ: chụp ở độ phân giải giảm (chia scaleDiv) và chỉ xử lý
 * tối đa 1 khung mỗi minIntervalMs. Khung bị bỏ qua chỉ tốn một lần close().
 * Toạ độ trong khung nhỏ này phải nhân scaleDiv để ra toạ độ màn hình thật.
 */
class ScreenCapturer(
    private val context: Context,
    private val projection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val densityDpi: Int,
    private val scaleDiv: Int = 2,
    private val minIntervalMs: Long = 300,
    private val onFrame: (Bitmap) -> Unit
) {
    private var thread: HandlerThread? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null

    @Volatile private var busy = false
    private var lastTs = 0L

    fun start() {
        val cw = width / scaleDiv
        val ch = height / scaleDiv

        val t = HandlerThread("capture").also { it.start() }
        thread = t
        val handler = Handler(t.looper)

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stop() }
        }, handler)

        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = r
        display = projection.createVirtualDisplay(
            "billiard-capture", cw, ch, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )

        r.setOnImageAvailableListener({ ir ->
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.elapsedRealtime()
                if (busy || now - lastTs < minIntervalMs) return@setOnImageAvailableListener
                busy = true
                lastTs = now
                val plane = image.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * cw
                val raw = Bitmap.createBitmap(
                    cw + rowPadding / plane.pixelStride, ch, Bitmap.Config.ARGB_8888
                )
                raw.copyPixelsFromBuffer(plane.buffer)
                val frame = if (rowPadding == 0) raw else {
                    val cropped = Bitmap.createBitmap(raw, 0, 0, cw, ch)
                    raw.recycle()
                    cropped
                }
                try { onFrame(frame) } finally { busy = false }
            } finally {
                image.close()
            }
        }, handler)
    }

    fun stop() {
        display?.release(); display = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
    }
}
