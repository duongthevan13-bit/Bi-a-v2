package com.example.billiardaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView
import android.graphics.RectF
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import android.graphics.Bitmap
import android.util.Log
import androidx.core.app.NotificationCompat
import org.opencv.android.OpenCVLoader
import java.io.File

/**
 * Foreground service (type mediaProjection):
 *  - hiện thông báo bắt buộc
 *  - tạo overlay trong suốt không chặn cảm ứng
 *  - bật ScreenCapturer trên luồng nền
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.billiardaim.START"
        const val ACTION_STOP = "com.example.billiardaim.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
    }

    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var overlay: OverlayView? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var aimButton: TextView? = null
    private var aimMode = false
    private lateinit var windowManager: WindowManager
    private val detector = Detector()
    private var cvReady = false
    private var lastDebugSave = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        // Android 14+: phải gọi startForeground (đúng type) TRƯỚC getMediaProjection.
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) { shutdown(); return }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cvReady = OpenCVLoader.initLocal()
        addOverlay()
        addAimButton()   // thêm SAU overlay để nằm trên cùng
        if (!cvReady) overlay?.setStatus("OpenCV LOAD FAILED")
        startCapture()
    }

    private fun addOverlay() {
        val view = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Mặc định không nhận cảm ứng để không cản thao tác bên dưới.
            // Nút AIM (setAimMode) bỏ cờ NOT_TOUCHABLE khi cần kéo chọn hướng ngắm.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        windowManager.addView(view, lp)
        overlay = view
        overlayLp = lp
    }

    /**
     * Nút tròn nhỏ bật/tắt chế độ ngắm. Tắt: overlay không nhận cảm ứng, game bên dưới
     * chơi bình thường. Bật: overlay nhận cảm ứng để kéo chọn hướng, thả tay là "chọc".
     */
    private fun addAimButton() {
        val d = resources.displayMetrics.density
        val btn = TextView(this).apply {
            text = "AIM"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)          // không dùng chữ trắng: tránh lẫn bi trắng
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CCFF6D00"))
            }
            setOnClickListener { setAimMode(!aimMode) }
        }
        val size = (52 * d).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (8 * d).toInt()
            y = (96 * d).toInt()
        }
        windowManager.addView(btn, lp)
        aimButton = btn
    }

    private fun setAimMode(on: Boolean) {
        val view = overlay ?: return
        val lp = overlayLp ?: return
        aimMode = on
        lp.flags = if (on) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        runCatching { windowManager.updateViewLayout(view, lp) }
        aimButton?.text = if (on) "AIM\nON" else "AIM"
    }

    @Suppress("DEPRECATION")
    private fun startCapture() {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        // Thiết kế cho 1980x890 @ 360dpi, nhưng lấy kích thước thật để chạy đúng trên mọi máy.
        // Tỉ lệ chính xác từ khung chụp nhỏ về màn hình thật (tránh lệch 1px do làm tròn).
        val sx = metrics.widthPixels.toFloat() / (metrics.widthPixels / 2)
        val sy = metrics.heightPixels.toFloat() / (metrics.heightPixels / 2)
        capturer = ScreenCapturer(
            this, projection!!,
            metrics.widthPixels, metrics.heightPixels, metrics.densityDpi
        ) { frame ->
            if (cvReady) {
                try {
                    val r = detector.process(frame)
                    overlay?.setTable(r.table?.let { RectF(it.left * sx, it.top * sy, it.right * sx, it.bottom * sy) })
                    overlay?.setCueBall(r.ball?.let { PointF(it.x * sx, it.y * sy) }, r.ballRadius * sx)
                    overlay?.setStatus(
                        "ban:${if (r.table != null) "OK(${r.tableAreaPct}%)" else "KHONG"} " +
                            "bi:${if (r.ball != null) "OK" else "KHONG"} blob:${r.whiteBlobs} ${r.ms}ms"
                    )
                    // Khi chưa nhận được bàn/bi: lưu 1 khung mỗi 8 giây để soi.
                    if ((r.table == null || r.ball == null) &&
                        System.currentTimeMillis() - lastDebugSave > 8000) {
                        lastDebugSave = System.currentTimeMillis()
                        saveDebugFrame(frame)
                    }
                } catch (t: Throwable) {
                    Log.e("BilliardAim", "detect failed", t)
                    overlay?.setStatus("Loi: ${t.javaClass.simpleName}")
                }
            }
            // Giai đoạn 3: tính phản xạ rồi gọi overlay?.setAimPath(...).
            frame.recycle()
        }.also { it.start() }
    }

    private fun saveDebugFrame(frame: Bitmap) {
        runCatching {
            val f = File(getExternalFilesDir(null), "debug_frame.jpg")
            f.outputStream().use { frame.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW
            )
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun shutdown() {
        capturer?.stop(); capturer = null
        aimButton?.let { runCatching { windowManager.removeView(it) } }; aimButton = null
        overlay?.let { runCatching { windowManager.removeView(it) } }; overlay = null; overlayLp = null
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
